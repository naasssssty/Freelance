package dit.hua.gr.backend.model;

public enum ApplicationStatus {
    WAITING, APPROVED, REJECTED
}
