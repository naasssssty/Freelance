package dit.hua.gr.backend.model;

public enum NotificationType {
    APPLICATION_RECEIVED,
    APPLICATION_ACCEPTED,
    APPLICATION_REJECTED,
    PROJECT_COMPLETED,
    NEW_MESSAGE,
    REPORT_STATUS_CHANGED
}