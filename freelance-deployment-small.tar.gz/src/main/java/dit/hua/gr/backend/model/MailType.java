package dit.hua.gr.backend.model;

public enum MailType {
    VERIFICATION,
    PASSWORD_RESET,
    PROJECT_NOTIFICATION,
    APPLICATION_NOTIFICATION
} 