package dit.hua.gr.backend.model;

public enum ProjectStatus {
    PENDING, APPROVED, DENIED, IN_PROGRESS, COMPLETED, EXPIRED
}
