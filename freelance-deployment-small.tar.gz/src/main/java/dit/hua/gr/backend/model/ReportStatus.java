package dit.hua.gr.backend.model;

public enum ReportStatus {
    PENDING, IN_REVIEW, RESOLVED, DISMISSED
} 