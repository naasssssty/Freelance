package dit.hua.gr.backend.model;

public enum Role {
    ADMIN,
    FREELANCER,
    CLIENT
}
